import React, { useState } from 'react';

const  NameList = () => {
    const [name, setName] = useState('');
    const [names, setNames] = useState([]);

    const handleInputChange = (event) => {
        setName(event.target.value);
    };

    const handleAddName = () => {
        if (name.trim()) {
            setNames([...names, name]);
            setName('');
        }
    };

    const handleChangeName = (index) => {
        if (name.trim()) {
            const updatedNames = names.map((currentName, i) =>
                i === index ? name : currentName
            );
            setNames(updatedNames);
            setName('');
        }
    };

    return (
        <div>
            <input
                type="text"
                value={name}
                onChange={handleInputChange}
                placeholder="Введите имя"
            />
            <button
                onClick={handleAddName}
                disabled={!name.trim()}
            >
                Добавить
            </button>

            {names.length === 0 ? (
                <p>Список пуст</p>
            ) : (
                <ul>
                    {names.map((currentName, index) => (
                        <li key={index}>
                            {currentName}
                            <button
                                onClick={() => handleChangeName(index)}
                                disabled={!name.trim()}
                            >
                                Поменять
                            </button>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}

export default NameList;
